module.exports = {
  name: "Mango",
  color: "Yellow",
};

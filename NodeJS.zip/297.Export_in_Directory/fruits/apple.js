module.exports = {
  name: "Apple",
  color: "Red",
};

const apple = require("./apple.js");
const banana = require("./banana.js");
const mango = require("./mango.js");
const orange = require("./orange.js");

let fruits = [apple, banana, mango, orange];

module.exports = fruits;

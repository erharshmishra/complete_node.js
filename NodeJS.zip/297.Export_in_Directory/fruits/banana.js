module.exports = {
  name: "Banana",
  color: "Yellow",
};

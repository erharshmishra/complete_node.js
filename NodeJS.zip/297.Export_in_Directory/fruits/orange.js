module.exports = {
  name: "Orange",
  color: "Orange",
};

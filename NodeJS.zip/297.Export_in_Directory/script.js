const info = require("./fruits");
console.log(info);

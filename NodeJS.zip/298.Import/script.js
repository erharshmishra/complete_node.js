// import { sum } from './math.js';
// import { subtract } from './math.js';
import { sum, subtract } from "./math.js";

console.log(sum(2, 3));
console.log(subtract(2, 3));

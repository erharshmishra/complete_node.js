const math = require("./math.js");
console.log(math.sum(5, 3));

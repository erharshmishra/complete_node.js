console.log(process);
console.log(process.argv);
